﻿namespace StoreClient.SQL
{
    public partial class SQLEngine
    {
        public enum ProductAttributes
        {
            Name,
            CompanyPrice,
            WholesalePrice,
            RetailPrice
        }
    }
}
